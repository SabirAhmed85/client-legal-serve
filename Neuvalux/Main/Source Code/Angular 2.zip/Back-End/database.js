module.exports = function() {
  return 'localhost:27017/expressshoppingcart';
}
