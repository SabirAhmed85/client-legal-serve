
var orderAPI = {

    add: function(req, res) {
        var db = req.db;
        var productTable = db.get('products');
        var orderTable = db.get('orders');
        var orderDetailsTable = db.get('orderdetails'); 
        var newOrder = {
            id: req.body.tx, 
            created: new Date().toLocaleDateString(),
            status: 'pending',
            username: req.body.username
        };
        orderTable.insert(newOrder,  function(error, result) {            
                var orderdetails = [];
                for(var i = 0; i < req.body.ordersDetail.length; i++) {
                    orderdetails.push({
                            orderId: req.body.tx,
                            productId: req.body.ordersDetail[i].productId,
                            price: req.body.ordersDetail[i].price,
                            quantity: req.body.ordersDetail[i].quantity
                        });
                }
                orderDetailsTable.insert(orderdetails, function(error, result){});
                    
        });
            
    },
    findByUsername: function(req, res) {
        var db = req.db;
        var ordersTable = db.get('orders');
        ordersTable.find({username: req.params.username}, function(e, orders) {
            res.write(JSON.stringify(orders));
            res.end();
        });
    },
    find: function(req, res) {
        var db = req.db;
        var ordersTable = db.get('orders');
        var ordersDetailTable = db.get('orderdetails');
        var ordersTable = db.get('orders');
        var settingsTable = db.get('settings');         
        ordersDetailTable.aggregate({
                $lookup:{
                    from:"products",
                    localField:"productId",
                    foreignField:"id",
                    as:"productInfo"
                }                
            }, function(e, result) {                     
                    settingsTable.findOne({key: 'base_url'}, function(e, setting){  
                        var orderDetails = [];
                        for(var i = 0; i < result.length; i++) {
                            if(result[i].orderId == req.params.id) {
                                result[i].productInfo[0].photo = setting.value + result[i].productInfo[0].photo;
                                orderDetails.push(result[i]);
                            }
                        }
                        res.write(JSON.stringify(orderDetails));
                        res.end();
                    });
            });
    },
    sum: function(req, res) {
        var db = req.db;
        var ordersDetailTable = db.get('orderdetails');
        ordersDetailTable.find({orderId: req.params.orderId}, function(e, orderDetails) {
            var s = 0;
            for(var i = 0; i < orderDetails.length; i++) {
                s += orderDetails[i].price * orderDetails[i].quantity;
            }
            res.write(JSON.stringify({sum: s}));
            res.end();
        });
    }
  
  
  
};

module.exports = orderAPI;
