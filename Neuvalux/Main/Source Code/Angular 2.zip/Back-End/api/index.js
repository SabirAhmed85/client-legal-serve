var express = require('express');
var router = express.Router();

var categoryAPI = require('./categoryAPI.js');
var brandAPI = require('./brandAPI.js');
var productAPI = require('./productAPI.js');
var settingAPI = require('./settingAPI.js');
var orderAPI = require('./orderAPI.js');
var accountAPI = require('./accountAPI.js');

// Category API
router.get('/category/find_all', categoryAPI.findAll);
router.get('/category/find_by_id/:id', categoryAPI.find);

// Brand API
router.get('/brand/find_all', brandAPI.findAll);
router.get('/brand/find_by_id/:id', brandAPI.find);

// Product API
router.get('/product/find_all', productAPI.findAll);
router.get('/product/find_latest', productAPI.findLatest);
router.get('/product/find_featured', productAPI.findFeatured);
router.get('/product/find_most_viewed', productAPI.findMostViewed);
router.get('/product/find_by_id/:id', productAPI.find);
router.get('/product/search_by_category_id/:categoryId', productAPI.findByCategory);
router.get('/product/search_by_brand_id/:brandId', productAPI.findByBrand);
router.get('/product/search/:keyword', productAPI.search);
router.get('/product/find_best_seller', productAPI.findBestSeller);
router.get('/product/search_related_by_category_id/:id', productAPI.findRelated);

// Order API
router.get('/order/findByUsername/:username', orderAPI.findByUsername);
router.get('/order/find/:id', orderAPI.find);
router.post('/order/create', orderAPI.add);
router.get('/order/sum/:orderId', orderAPI.sum);

// Account API
router.post('/account/signup', accountAPI.signUp);
router.post('/account/login', accountAPI.login);
router.get('/account/profile/:username', accountAPI.profile);
router.post('/account/profile', accountAPI.saveProfile);

// Setting API
router.get('/setting/find_by_key/:key', settingAPI.find);
router.get('/setting/group/:group', settingAPI.findByGroup);

module.exports = router;
