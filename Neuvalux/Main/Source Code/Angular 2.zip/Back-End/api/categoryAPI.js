
var categoryAPI = {

  findAll: function(req, res) {
    var db = req.db;
    var categoryTable = db.get('categories'); 
    categoryTable.find({status: true}, {}, function(error, result){
        res.write(JSON.stringify(result));
        res.end();
    });
  },  
  find: function(req, res) {
    var db = req.db;
    var categoryTable = db.get('categories'); 
    categoryTable.findOne({$or:[{id: req.params.id}, {'subcategories.id': req.params.id}]}, function(e, result){   
        if(result.id == req.params.id) {
            res.write(JSON.stringify(result));
            res.end();
        } else {
            if(result.subcategories != null) {
                for(var i = 0; i < result.subcategories.length; i++) {
                    if(result.subcategories[i].id == req.params.id) {
                        res.write(JSON.stringify(result.subcategories[i]));
                        res.end();
                        break;
                    }
                }
            }
        }
    });
    
  }
  
};

module.exports = categoryAPI;
