
var brandAPI = {

  findAll: function(req, res) {
    var db = req.db;
    var brandsTable = db.get('brands'); 
    brandsTable.find({status: true}, {}, function(error, result){
        res.write(JSON.stringify(result));
        res.end();
    });
  },
  find: function(req, res) {
    var db = req.db;
    var brandsTable = db.get('brands'); 
    brandsTable.findOne({$and: [{id: req.params.id}, {status: true}]}, function(e, result){  
        res.write(JSON.stringify(result));
        res.end();
    });
  }
  
  
  
};

module.exports = brandAPI;
