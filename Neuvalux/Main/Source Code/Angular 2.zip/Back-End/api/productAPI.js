
var productAPI = {

  findAll: function(req, res) {
    var db = req.db;
    var productsTable = db.get('products'); 
    var settingsTable = db.get('settings'); 
    productsTable.find({status: true}, {}, function(error, products){
        settingsTable.findOne({key: 'base_url'}, function(e, setting){  
            for(var i = 0; i < products.length; i++) {
                products[i].photo = setting.value + products[i].photo;
            }
            res.write(JSON.stringify(products));
            res.end();
        });        
    });
  },  
  find: function(req, res) {
    var db = req.db;
    var productsTable = db.get('products'); 
    var settingsTable = db.get('settings'); 
    productsTable.findOne({$and: [{id: req.params.id}, {status: true}]}, function(e, product){
        productsTable.update({id: req.params.id}, {$set : {views: product.views + 1}}, function(e, result){
            settingsTable.findOne({key: 'base_url'}, function(e, setting){  
                product.photo = setting.value + product.photo;            
                res.write(JSON.stringify(product));
                res.end();
            });
        });
    });    
  },  
  findLatest: function(req, res) {
    var db = req.db;
    var productsTable = db.get('products');
    var settingsTable = db.get('settings');    
    settingsTable.find({$or: [{key: 'latest_products'}, {key: 'base_url'}]},{}, function(e, settings){
        productsTable.find({status: true}, { limit : settings[0].value, sort : { _id : -1 } }, function(e, products){
            for(var i = 0; i < products.length; i++) {
                products[i].photo = settings[1].value + products[i].photo;
            }
            res.write(JSON.stringify(products));
            res.end();
        });
    });
  },  
  findFeatured: function(req, res) {
    var db = req.db;
    var productsTable = db.get('products');
    var settingsTable = db.get('settings');    
    settingsTable.find({$or: [{key: 'features_products'}, {key: 'base_url'}]},{}, function(e, settings){
        productsTable.find({$and: [{status: true}, {special: true}]}, { limit : settings[0].value, sort : { _id : -1 } }, function(e, products){
            for(var i = 0; i < products.length; i++) {
                products[i].photo = settings[1].value + products[i].photo;
            }
            res.write(JSON.stringify(products));
            res.end();
        });
    });
  }, 
  findByCategory: function(req, res) {
    var db = req.db;
    var productsTable = db.get('products'); 
    var settingsTable = db.get('settings'); 
    productsTable.find({$and: [{status: true}, {categoryId: req.params.categoryId}]}, { }, function(e, products){
        settingsTable.findOne({key: 'base_url'}, function(e, setting){  
            for(var i = 0; i < products.length; i++) {
                products[i].photo = setting.value + products[i].photo;
            }
            res.write(JSON.stringify(products));
            res.end();
        });      
    });
  },  
  search: function(req, res) {
    var db = req.db;
    var productsTable = db.get('products'); 
    var settingsTable = db.get('settings'); 
    productsTable.find({$and: [{status: true}, {"name" : {$regex : ".*" + req.params.keyword + ".*"}}]}, { }, function(e, products){
        settingsTable.findOne({key: 'base_url'}, function(e, setting){  
            for(var i = 0; i < products.length; i++) {
                products[i].photo = setting.value + products[i].photo;
            }
            res.write(JSON.stringify(products));
            res.end();
        });
    });
  },  
  findByBrand: function(req, res) {
    var db = req.db;
    var productsTable = db.get('products'); 
    var settingsTable = db.get('settings'); 
    productsTable.find({$and: [{status: true}, {brandId: req.params.brandId}]}, { }, function(e, products){
        settingsTable.findOne({key: 'base_url'}, function(e, setting){  
            for(var i = 0; i < products.length; i++) {
                products[i].photo = setting.value + products[i].photo;
            }
            res.write(JSON.stringify(products));
            res.end();
        });
    });
  },  
  findBestSeller: function(req, res) {
    var db = req.db;
    var productsTable = db.get('products'); 
    var settingsTable = db.get('settings');  
    var orderdetailsTable = db.get('orderdetails');    
    settingsTable.findOne({key: 'best_seller'},{}, function(e, setting){            
                orderdetailsTable.aggregate( 
                [ 
                   { 
                        $group : { 
                            _id : "$productId",
                            totalQuantity: {$sum: "$quantity"} 
                        }    
                   },
                   { 
                        $sort : { 'totalQuantity': -1 }
                   },
                   {
                       $limit: setting.value
                   }
                ], function(err, result) {               
                    
                    var conditions = [];
                    for(var i = 0; i < result.length; i++) {
                        conditions.push({id: result[i]._id});
                    }                
                    productsTable.find({$or: conditions}, function(e, products) {
                        var finalResult = [];
                        for(var i = 0; i < result.length; i++) {
                            for(var j = 0; j < products.length; j++) {
                                if(result[i]._id == products[j].id) {
                                    finalResult.push(products[j]);
                                }
                            }
                        }             
                        settingsTable.findOne({key: 'base_url'}, function(e, setting){  
                            for(var i = 0; i < finalResult.length; i++) {
                                finalResult[i].photo = setting.value + finalResult[i].photo;
                            }
                            res.write(JSON.stringify(finalResult));
                            res.end();
                        });
                        
                    });
                });
            
            });
    },
    findRelated: function(req, res) {
        var db = req.db;
        var productsTable = db.get('products'); 
        var settingsTable = db.get('settings'); 
        productsTable.findOne({id: req.params.id}, function(e, product){
            productsTable.find({ $and: [ { id: { $ne: product.id } }, { categoryId: product.categoryId }, {status: true} ] }, { limit : 9 }, function(e, products){
                    settingsTable.findOne({key: 'base_url'}, function(e, setting){  
                        for(var i = 0; i < products.length; i++) {
                            products[i].photo = setting.value + products[i].photo;
                        }
                        res.write(JSON.stringify(products));
                        res.end();
                    });
            });
        });
    },
    findMostViewed: function(req, res) {
        var db = req.db;
        var productsTable = db.get('products'); 
        var settingsTable = db.get('settings');
        settingsTable.findOne({key: 'mosted_view'},{}, function(e, setting){
            productsTable.find({status: true}, { limit : setting.value, sort : { views : -1 } }, function(e, products){
                    settingsTable.findOne({key: 'base_url'}, function(e, setting){  
                        for(var i = 0; i < products.length; i++) {
                            products[i].photo = setting.value + products[i].photo;
                        }
                        res.write(JSON.stringify(products));
                        res.end();
                    });
            });
        });
    }
  
  
  
  
};

module.exports = productAPI;
