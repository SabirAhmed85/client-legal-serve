
var settingAPI = {

  find: function(req, res) {
    var db = req.db;
    var settingsTable = db.get('settings'); 
    settingsTable.findOne({key: req.params.key}, function(e, result){  
        res.write(JSON.stringify(result));
        res.end();
    });
  },
  findByGroup: function(req, res) {
    var db = req.db;
    var settingsTable = db.get('settings'); 
    settingsTable.find({group: req.params.group}, {}, function(error, result){
        res.write(JSON.stringify(result));
        res.end();
    });
  }
  
  
  
};

module.exports = settingAPI;
