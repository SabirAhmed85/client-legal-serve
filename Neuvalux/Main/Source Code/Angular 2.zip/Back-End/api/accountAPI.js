var bcrypt = require('bcrypt');

var accountAPI = {

    signUp: function(req, res) {
        var db = req.db;
        var accountsTable = db.get('accounts'); 
        accountsTable.count({username: req.body.username}, function(e, count) {
                if(count == 0) {
                    bcrypt.hash(req.body.password, 13, function(err, hash) {
                        req.body.password = hash;
                        req.body.status = true;
                        req.body.roleId = 'customer';
                        accountsTable.insert(req.body, function(err, result){
                            res.write(JSON.stringify({count: 0}));
                            res.end();                        
                        });
                    });
                } else {
                    res.write(JSON.stringify({count: 1}));
                    res.end();
                }
            });
    },
    login: function(req, res) {
      var db = req.db;
        var accountsTable = db.get('accounts'); 
        accountsTable.findOne({$and: [{username: req.body.username}, {status: true}, {roleId: 'customer'}]}, function(e, account){
                if(account != null) {
                    bcrypt.compare(req.body.password, account.password, function(err, res1) {
                        if(res1) {
                           res.write(JSON.stringify({count: 1}));
                            res.end();
                        } else {
                            res.write(JSON.stringify({count: 0}));
                            res.end();
                        }
                    });
                } else {
                    res.write(JSON.stringify({count: 0}));
                    res.end();
                }
            });
    },
    profile: function(req, res) {
        var db = req.db;
        var accountsTable = db.get('accounts'); 
        accountsTable.findOne({$and: [{username: req.params.username}, {status: true}, {roleId: 'customer'}]}, function(e, account){
                res.write(JSON.stringify(account));
                res.end();
        });
    },
    saveProfile: function(req, res) {
        var db = req.db;
        var accountTable = db.get('accounts'); 
        accountTable.findOne({username: req.body.username}, function(e, account) {
                if(req.body.password != '') {
                    bcrypt.hash(req.body.password, 13, function(err, hash) {
                        accountTable.update({username: req.body.username}, {$set : {password: hash, fullName: req.body.fullName, email: req.body.email}}, function(e, result) {
                            res.write(JSON.stringify({count: 1}));
                            res.end();
                        });
                    });
                } else {                    
                    accountTable.update({username: req.body.username}, {$set : {fullName: req.body.fullName, email: req.body.email}}, function(e, result) {
                        res.write(JSON.stringify({count: 1}));
                        res.end();
                    });
                }
            });
    }
  
  
  
};

module.exports = accountAPI;
